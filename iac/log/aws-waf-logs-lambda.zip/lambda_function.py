import base64
import json
from datetime import datetime, timedelta

def lambda_handler(event, context):
    output = []

    try:

        for record in event["records"]:

            message = json.loads(base64.b64decode(
                record['data']).decode('utf-8'))
            print('Country: ', message["httpRequest"]["country"])
            print('Action: ', message["action"])
            print('User Agent: ',
                  message["httpRequest"]["headers"][1]["value"])

            # 시간 정규화 작업
            timestamp = message["timestamp"]
            timestamp /= 1000
            timestamp = datetime.utcfromtimestamp(timestamp) + timedelta(hours=9)
            timestamp = timestamp.strftime('%Y-%m-%dT%H:%M:%S.%f+0900')

            message["timestamp"] = timestamp
            print(timestamp)

            action = message["action"]
            country = message["httpRequest"]["country"]
            CHECK_BLOCKS = check_block(action)
            message["CHECK_BLOCK"] = CHECK_BLOCKS
            
            data = json.dumps(message)

            output_record = {
                "recordId": record['recordId'],
                "result": "Ok",
                "data": base64.b64encode(data.encode('utf-8')).decode('utf-8')
            }
            
            output.append(output_record)
            
        print('Successfully processed {} records.'.format(len(event['records'])))
        
        return {"records": output}
    
    except Exception as e:
        
        print(e)

        
def check_block(action):
    
    if "BLOCK" in action:
        return 1
    else:
        return 0
